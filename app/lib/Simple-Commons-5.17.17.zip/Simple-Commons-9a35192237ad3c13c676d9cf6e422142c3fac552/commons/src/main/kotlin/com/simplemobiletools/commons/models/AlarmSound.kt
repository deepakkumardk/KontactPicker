package com.simplemobiletools.commons.models

data class AlarmSound(val id: Int, var title: String, var uri: String)
